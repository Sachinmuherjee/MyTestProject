module.exports = {
  "verbose": true
}
